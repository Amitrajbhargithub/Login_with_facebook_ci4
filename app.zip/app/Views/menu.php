			<div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-6" style="height: 50px;word-spacing: 30px;font-size: 25px;">
                    <a href="<?=base_url("logout")?>" class="btn btn-primary">Logout</a>
                </div>
                <div class="col-md-2"></div>
            </div>